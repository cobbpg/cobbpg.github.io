Stunt Car Racer for Apple II

This is a port of the C64 version of Stunt Car Racer that should run on any
Apple II with 48K RAM. In order to squeeze the game into such a tight space,
I had to get rid of non-essential features, such as:

- graphical menu
- hotseat multiplayer championship
- saving the seasons or the track records on disk
- entering a name for the player
- showing the wheels in the game

On the plus side, the single-player experience is complete with seasons and AI
drivers, and apart from the wheels it has all the graphical elements of the
original. Even the frame rate is reasonable, albeit a bit slower than on the
C64.

The game is fully controlled with the joystick. The race can be interrupted
with the Esc key, and the S key can be used to turn off sky rendering for a
little extra speed. In the menu the number keys can be used to select the
desired options directly. For everything else you can consult the original
game's manual.

Patai Gergely, 2023